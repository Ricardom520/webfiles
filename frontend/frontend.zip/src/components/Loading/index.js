/**
 * index
 * @Author: huangfs
 * @Date: 2019-02-27
 * @Project: cms
 */

import Loading from './Loading';

export default Loading;
