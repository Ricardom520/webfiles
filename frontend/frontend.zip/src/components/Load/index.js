import React, { Component } from 'react';
import './load.less';

class Load extends Component {
    render() {
        return (
            <div className="LoadContainer">123</div>
        )
    }
}

export default Load;