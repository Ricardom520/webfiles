import actionTypes from '../../actions/actionType';

let initState = {

}

export default (state = initState, action) => {
    switch (action.type) {
        default:
            return state;
    }
}